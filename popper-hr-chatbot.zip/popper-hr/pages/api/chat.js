// pages/api/chat.js
// ─────────────────────────────────────────────────────────────
//  Serverless function — llama a Mistral con la API key segura.
//  El browser NUNCA ve MISTRAL_API_KEY.
// ─────────────────────────────────────────────────────────────
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

function buildSystemPrompt(emp) {
  const vac = emp.vacations
  const pay = emp.payroll
  const abs = emp.absences || []
  const ben = emp.benefits || []

  return `Eres Aria, la asistente virtual de Recursos Humanos de Grupo Popper.
Grupo Popper es una empresa argentina líder en su sector. Tu rol es ayudar a los empleados con consultas de RRHH de forma profesional, empática y precisa.

PERFIL DEL EMPLEADO (datos en tiempo real desde Naaloo):
• Nombre completo : ${emp.name || 'No disponible'}
• Email           : ${emp.email || ''}
• Área            : ${emp.area || 'No registrada'}
• Cargo           : ${emp.position || 'No registrado'}
• Responsable     : ${emp.manager || 'No registrado'}

VACACIONES:
• Días totales    : ${vac?.total ?? 'No disponible'}
• Días usados     : ${vac?.used ?? 'No disponible'}
• Días restantes  : ${vac?.remaining ?? 'No disponible'}
• Vencimiento     : ${vac?.nextExpiry || 'fin de año'}

NÓMINA:
• Próximo pago    : ${pay?.nextPayment || 'No disponible'}

AUSENCIAS RECIENTES: ${abs.length > 0
    ? abs.map(a => `${a.date} — ${a.type} (${a.status})`).join(' | ')
    : 'Ninguna registrada'}

BENEFICIOS ACTIVOS: ${ben.length > 0 ? ben.join(', ') : 'No disponibles'}

INSTRUCCIONES IMPORTANTES:
- Dirigite siempre al empleado por su nombre de pila
- Usa los datos de arriba para responder consultas concretas (vacaciones, nómina, beneficios)
- NUNCA inventes datos que no estén en el perfil
- Para trámites, explicá los pasos y cuándo derivar a RRHH
- Si preguntan por algo fuera de tu alcance, indicá que consulten a rrhh@grupopopper.com
- Responde en español rioplatense (vos, sos, tenés), tono profesional pero cercano
- Usá emojis con moderación
- Estructurá con listas cuando haya pasos o múltiples ítems`
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' })

  // 1. Autenticar usuario
  const token = (req.headers.authorization || '').replace('Bearer ', '')
  if (!token) return res.status(401).json({ error: 'No autenticado' })

  const { data: { user }, error } = await supabase.auth.getUser(token)
  if (error || !user) return res.status(401).json({ error: 'Sesión inválida' })

  const { messages, employee } = req.body
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Falta el campo messages' })
  }

  try {
    const mistralRes = await fetch('https://api.mistral.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.MISTRAL_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'mistral-small-latest',
        messages: [
          { role: 'system', content: buildSystemPrompt(employee || {}) },
          ...messages.map(m => ({ role: m.role, content: m.content })),
        ],
        max_tokens: 900,
        temperature: 0.5,
      }),
    })

    if (!mistralRes.ok) {
      const err = await mistralRes.json().catch(() => ({}))
      throw new Error(err?.message || `Error Mistral ${mistralRes.status}`)
    }

    const data = await mistralRes.json()
    const reply = data.choices[0].message.content

    return res.status(200).json({ reply })

  } catch (e) {
    console.error('Error Mistral:', e.message)
    return res.status(500).json({ error: 'Error al procesar tu consulta. Intentá nuevamente.' })
  }
}
