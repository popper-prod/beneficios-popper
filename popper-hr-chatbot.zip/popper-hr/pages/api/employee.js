// pages/api/employee.js
// ─────────────────────────────────────────────────────────────
//  Serverless function — corre en Vercel, las keys NUNCA
//  llegan al browser del empleado.
// ─────────────────────────────────────────────────────────────
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

const NAALOO_BASE = process.env.NAALOO_BASE_URL || 'https://api.naaloo.com'
const NAALOO_KEY  = process.env.NAALOO_API_KEY

// Helpers para llamar a Naaloo
async function naalooGet(path) {
  const res = await fetch(`${NAALOO_BASE}${path}`, {
    headers: {
      'x-api-key': NAALOO_KEY,
      'Content-Type': 'application/json',
    },
  })
  if (!res.ok) throw new Error(`Naaloo error ${res.status} en ${path}`)
  return res.json()
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Método no permitido' })

  // 1. Verificar sesión de Supabase via token en header
  const authHeader = req.headers.authorization || ''
  const token = authHeader.replace('Bearer ', '')
  if (!token) return res.status(401).json({ error: 'No autenticado' })

  const { data: { user }, error: authErr } = await supabase.auth.getUser(token)
  if (authErr || !user) return res.status(401).json({ error: 'Sesión inválida' })

  // 2. Buscar el empleado en nuestra tabla (que tiene el naaloo_id)
  const { data: emp, error: dbErr } = await supabase
    .from('employees')
    .select('*')
    .eq('email', user.email)
    .single()

  if (dbErr || !emp) {
    return res.status(404).json({ error: 'Empleado no encontrado en el sistema. Contactá a RRHH.' })
  }

  const id = emp.naaloo_id

  try {
    // 3. Traer datos de Naaloo en paralelo
    // ⚠️  Ajustar endpoints según documentación real de Naaloo
    const [profile, vacations, absences, payroll, benefits] = await Promise.allSettled([
      naalooGet(`/v1/employees/${id}`),
      naalooGet(`/v1/employees/${id}/vacations`),
      naalooGet(`/v1/employees/${id}/absences`),
      naalooGet(`/v1/employees/${id}/payroll`),
      naalooGet(`/v1/employees/${id}/benefits`),
    ])

    // Función para extraer valor o null si falló
    const val = (r) => r.status === 'fulfilled' ? r.value : null

    const profileData = val(profile)
    const vacData     = val(vacations)
    const absData     = val(absences)
    const payData     = val(payroll)
    const benData     = val(benefits)

    // 4. Normalizar respuesta (adaptar claves según respuesta real de Naaloo)
    const employeeData = {
      name:     profileData?.full_name || profileData?.name || emp.full_name,
      area:     profileData?.department || profileData?.area || emp.area,
      position: profileData?.position || profileData?.job_title || emp.position,
      manager:  profileData?.manager_name || profileData?.manager,
      email:    user.email,
      vacations: vacData ? {
        total:      vacData.total_days     || vacData.total,
        used:       vacData.used_days      || vacData.used,
        remaining:  vacData.remaining_days || vacData.remaining,
        nextExpiry: vacData.expiry_date    || vacData.next_expiry,
      } : null,
      absences: Array.isArray(absData) ? absData.slice(0, 5).map(a => ({
        date:   a.date || a.start_date,
        type:   a.type || a.absence_type,
        status: a.status,
      })) : [],
      payroll: payData ? {
        nextPayment: payData.next_payment_date || payData.payment_date,
        amount:      payData.net_amount        || payData.net_salary,
        currency:    payData.currency          || 'ARS',
      } : null,
      benefits: Array.isArray(benData)
        ? benData.map(b => b.name || b.description || b.benefit_name)
        : [],
    }

    return res.status(200).json(employeeData)

  } catch (e) {
    console.error('Error Naaloo:', e.message)
    // Si Naaloo falla, devolver datos mínimos desde Supabase
    return res.status(200).json({
      name:     emp.full_name,
      area:     emp.area,
      position: emp.position,
      email:    user.email,
      _warning: 'Datos de Naaloo no disponibles temporalmente',
    })
  }
}
