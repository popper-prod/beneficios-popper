// pages/index.jsx
import { useState, useRef, useEffect } from 'react'
import { supabase } from '../lib/supabase'

// ─── ESTILOS GLOBALES ────────────────────────────────────────
const G = `
  @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --navy:   #0b1628;
    --navy2:  #111f38;
    --gold:   #c9a84c;
    --gold2:  #e8c96a;
    --gold3:  #f5dfa0;
    --text:   #e8ecf4;
    --muted:  #7a8aaa;
    --border: rgba(201,168,76,0.18);
    --red:    #f87171;
  }
  html, body { height: 100%; font-family: 'DM Sans', sans-serif; background: var(--navy); color: var(--text); }
  @keyframes fadeUp  { from { opacity:0; transform:translateY(18px) } to { opacity:1; transform:translateY(0) } }
  @keyframes slideIn { from { opacity:0; transform:translateX(-10px) } to { opacity:1; transform:translateX(0) } }
  @keyframes dot     { 0%,80%,100% { transform:scale(.55); opacity:.4 } 40% { transform:scale(1); opacity:1 } }
  @keyframes spin    { to { transform:rotate(360deg) } }
  input::placeholder, textarea::placeholder { color: var(--muted); }
  ::-webkit-scrollbar { width: 5px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: rgba(201,168,76,0.2); border-radius: 10px; }
`

// ─── COMPONENTES PEQUEÑOS ────────────────────────────────────
function Logo({ size = 44 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: size * 0.22, flexShrink: 0,
      background: 'linear-gradient(135deg, #c9a84c, #8a6820)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'Outfit', sans-serif", fontWeight: 800,
      fontSize: size * 0.37, color: '#fff', letterSpacing: '-0.5px',
      boxShadow: '0 4px 18px rgba(201,168,76,0.38)',
    }}>GP</div>
  )
}

function Spinner({ size = 20 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      border: '2.5px solid rgba(201,168,76,0.2)',
      borderTopColor: '#c9a84c',
      animation: 'spin 0.7s linear infinite', flexShrink: 0,
    }} />
  )
}

function TypingDots() {
  return (
    <div style={{ display: 'flex', gap: 5, padding: '4px 2px' }}>
      {[0,1,2].map(i => (
        <span key={i} style={{
          width: 7, height: 7, borderRadius: '50%',
          background: '#c9a84c', display: 'inline-block',
          animation: `dot 1.3s ease-in-out ${i * 0.18}s infinite`,
        }} />
      ))}
    </div>
  )
}

function InputField({ label, type = 'text', value, onChange, onKeyDown, placeholder, autoFocus }) {
  const [focused, setFocused] = useState(false)
  return (
    <label style={{ display: 'block' }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', marginBottom: 6, letterSpacing: '0.5px', textTransform: 'uppercase' }}>
        {label}
      </div>
      <input
        type={type} value={value} onChange={onChange} onKeyDown={onKeyDown}
        placeholder={placeholder} autoFocus={autoFocus}
        onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
        style={{
          width: '100%', padding: '13px 16px',
          background: 'rgba(255,255,255,0.04)',
          border: `1px solid ${focused ? 'rgba(201,168,76,0.55)' : 'rgba(201,168,76,0.18)'}`,
          borderRadius: 12, color: 'var(--text)', fontSize: 14, outline: 'none',
          fontFamily: "'DM Sans', sans-serif", transition: 'border-color 0.2s',
        }}
      />
    </label>
  )
}

// ─── PANTALLA LOGIN ──────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState('')

  const handleLogin = async () => {
    if (!email || !password) { setError('Completá los dos campos.'); return }
    setError(''); setLoading(true)
    try {
      const { data, error: authErr } = await supabase.auth.signInWithPassword({ email, password })
      if (authErr) throw new Error('Credenciales incorrectas. Verificá tu email y contraseña.')
      onLogin(data.session)
    } catch (e) {
      setError(e.message)
    } finally { setLoading(false) }
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'radial-gradient(ellipse at 30% 20%, #162a4a 0%, var(--navy) 60%)',
      padding: 20,
    }}>
      {/* Grid decorativo */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
        backgroundImage: 'linear-gradient(rgba(201,168,76,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(201,168,76,0.04) 1px, transparent 1px)',
        backgroundSize: '60px 60px',
      }} />

      <div style={{
        position: 'relative', zIndex: 1,
        width: '100%', maxWidth: 430,
        background: 'rgba(13,22,42,0.95)', backdropFilter: 'blur(24px)',
        border: '1px solid var(--border)', borderRadius: 24,
        boxShadow: '0 32px 80px rgba(0,0,0,0.55)',
        overflow: 'hidden', animation: 'fadeUp 0.45s ease both',
      }}>
        <div style={{ height: 4, background: 'linear-gradient(90deg, #c9a84c, #8a6820, #c9a84c)' }} />

        <div style={{ padding: '40px 36px 36px' }}>
          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 30 }}>
            <Logo size={50} />
            <div>
              <div style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 19, color: '#f0f4ff' }}>
                Grupo Popper
              </div>
              <div style={{ fontSize: 12, color: 'var(--gold)', fontWeight: 500 }}>
                Portal de Recursos Humanos
              </div>
            </div>
          </div>

          <h2 style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 22, color: '#e8ecf4', marginBottom: 6 }}>
            Ingresá a tu cuenta
          </h2>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 26, lineHeight: 1.55 }}>
            Usá tu correo corporativo y contraseña
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <InputField label="Email corporativo" type="email" value={email}
              onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleLogin()}
              placeholder="nombre@grupopopper.com" autoFocus />

            <InputField label="Contraseña" type="password" value={password}
              onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleLogin()}
              placeholder="Tu contraseña" />
          </div>

          {error && (
            <div style={{
              marginTop: 14, background: 'rgba(220,60,60,0.1)',
              border: '1px solid rgba(220,60,60,0.28)', borderRadius: 10,
              padding: '10px 14px', color: 'var(--red)', fontSize: 13,
            }}>⚠️ {error}</div>
          )}

          <button onClick={handleLogin} disabled={loading} style={{
            width: '100%', marginTop: 20, padding: '14px',
            background: loading ? 'rgba(201,168,76,0.25)' : 'linear-gradient(135deg, #c9a84c, #9a7230)',
            border: 'none', borderRadius: 12, color: '#fff',
            fontSize: 15, fontWeight: 700, cursor: loading ? 'default' : 'pointer',
            fontFamily: "'Outfit', sans-serif",
            boxShadow: loading ? 'none' : '0 6px 22px rgba(201,168,76,0.32)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
            transition: 'all 0.2s',
          }}>
            {loading ? <><Spinner size={18} /> Verificando...</> : 'Ingresar →'}
          </button>

          <p style={{ textAlign: 'center', marginTop: 18, fontSize: 12, color: 'var(--muted)', lineHeight: 1.6 }}>
            ¿Olvidaste tu contraseña?{' '}
            <span
              onClick={async () => {
                if (!email) { alert('Ingresá tu email primero'); return }
                await supabase.auth.resetPasswordForEmail(email)
                alert('Te enviamos un email para restablecer tu contraseña.')
              }}
              style={{ color: 'var(--gold)', cursor: 'pointer' }}
            >Recuperar acceso</span>
          </p>
        </div>
      </div>
    </div>
  )
}

// ─── BURBUJA DE MENSAJE ──────────────────────────────────────
function Bubble({ msg }) {
  const isUser = msg.role === 'user'
  return (
    <div style={{
      display: 'flex', flexDirection: isUser ? 'row-reverse' : 'row',
      gap: 10, alignItems: 'flex-end', marginBottom: 18,
      animation: 'slideIn 0.25s ease both',
    }}>
      <div style={{
        width: 33, height: 33, borderRadius: '50%', flexShrink: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: "'Outfit', sans-serif", fontWeight: 800, fontSize: 11,
        background: isUser
          ? 'linear-gradient(135deg, #1a3a6a, #0f2040)'
          : 'linear-gradient(135deg, #c9a84c, #8a6820)',
        color: '#fff',
        border: isUser ? '1.5px solid rgba(255,255,255,0.08)' : 'none',
        boxShadow: isUser ? 'none' : '0 3px 12px rgba(201,168,76,0.3)',
      }}>
        {isUser ? 'TÚ' : '✦'}
      </div>
      <div style={{
        maxWidth: '74%',
        background: isUser ? 'linear-gradient(135deg, #1d3d70, #142e58)' : 'rgba(255,255,255,0.04)',
        color: isUser ? '#e8ecf4' : '#cdd5e0',
        borderRadius: isUser ? '18px 5px 18px 18px' : '5px 18px 18px 18px',
        padding: '12px 16px', fontSize: 14, lineHeight: 1.68,
        whiteSpace: 'pre-wrap', wordBreak: 'break-word',
        border: isUser ? 'none' : '1px solid rgba(201,168,76,0.1)',
        boxShadow: isUser ? '0 4px 16px rgba(13,40,90,0.45)' : '0 2px 12px rgba(0,0,0,0.25)',
      }}>
        {msg.typing ? <TypingDots /> : msg.content}
      </div>
    </div>
  )
}

const QUICK_Q = [
  { icon: '🏖️', label: '¿Cuántos días de vacaciones me quedan?' },
  { icon: '🏥', label: '¿Cómo solicito una licencia médica?' },
  { icon: '💰', label: '¿Cuándo cobro la próxima nómina?' },
  { icon: '👶', label: '¿Cómo pido permiso de maternidad/paternidad?' },
  { icon: '📋', label: '¿Qué beneficios tengo activos?' },
  { icon: '🎓', label: '¿Hay capacitaciones disponibles?' },
]

// ─── PANTALLA CHAT ───────────────────────────────────────────
function ChatScreen({ session, employee, onLogout }) {
  const firstName = employee?.name?.split(' ')[0] || 'ahí'
  const [messages, setMessages] = useState([{
    role: 'assistant',
    content: `¡Hola, ${firstName}! 👋\n\nSoy Aria, tu asistente de RRHH de Grupo Popper. Tengo tu perfil actualizado desde Naaloo — por ejemplo, te quedan ${employee?.vacations?.remaining ?? '—'} días de vacaciones disponibles 🏖️\n\n¿En qué puedo ayudarte hoy?`,
  }])
  const [input, setInput]         = useState('')
  const [loading, setLoading]     = useState(false)
  const [sidebar, setSidebar]     = useState(true)
  const bottomRef = useRef(null)
  const inputRef  = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const send = async (text) => {
    const msg = text.trim()
    if (!msg || loading) return
    setInput('')
    const history = [...messages, { role: 'user', content: msg }]
    setMessages([...history, { role: 'assistant', typing: true }])
    setLoading(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ messages: history, employee }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error desconocido')
      setMessages([...history, { role: 'assistant', content: data.reply }])
    } catch (e) {
      setMessages([...history, { role: 'assistant', content: `⚠️ ${e.message}` }])
    } finally {
      setLoading(false)
      inputRef.current?.focus()
    }
  }

  const isFirst = messages.length <= 1

  return (
    <div style={{ height: '100vh', display: 'flex', background: 'radial-gradient(ellipse at 20% 10%, #162a4a 0%, var(--navy) 55%)' }}>

      {/* ── SIDEBAR ── */}
      <div style={{
        width: sidebar ? 270 : 0, flexShrink: 0, overflow: 'hidden',
        transition: 'width 0.3s ease',
        background: 'rgba(9,18,34,0.97)',
        borderRight: '1px solid var(--border)',
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ padding: 22, minWidth: 270, display: 'flex', flexDirection: 'column', height: '100%', overflowY: 'auto' }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
            <Logo size={34} />
            <span style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 14, color: '#f0f4ff' }}>Grupo Popper</span>
          </div>

          {/* Perfil */}
          <div style={{
            background: 'rgba(201,168,76,0.07)', border: '1px solid var(--border)',
            borderRadius: 14, padding: 16, marginBottom: 18,
          }}>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 15, color: '#f0f4ff', marginBottom: 2 }}>
              {employee?.name}
            </div>
            <div style={{ color: 'var(--gold)', fontSize: 12, fontWeight: 500, marginBottom: 8 }}>
              {employee?.position}
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.7 }}>
              📂 {employee?.area || '—'}<br />
              👤 {employee?.manager || '—'}
            </div>
          </div>

          {/* Vacaciones */}
          {employee?.vacations && (
            <div style={{ marginBottom: 18 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 10 }}>
                Mis Vacaciones
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 7 }}>
                {[
                  { label: 'Total', val: employee.vacations.total },
                  { label: 'Usados', val: employee.vacations.used },
                  { label: 'Quedan', val: employee.vacations.remaining, highlight: true },
                ].map(({ label, val, highlight }) => (
                  <div key={label} style={{
                    background: highlight ? 'rgba(201,168,76,0.12)' : 'rgba(255,255,255,0.03)',
                    border: `1px solid ${highlight ? 'rgba(201,168,76,0.3)' : 'rgba(255,255,255,0.06)'}`,
                    borderRadius: 10, padding: '10px 6px', textAlign: 'center',
                  }}>
                    <div style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 22, color: highlight ? 'var(--gold2)' : '#e8ecf4' }}>{val ?? '—'}</div>
                    <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 2 }}>{label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Beneficios */}
          {employee?.benefits?.length > 0 && (
            <div style={{ marginBottom: 18 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 10 }}>
                Mis Beneficios
              </div>
              {employee.benefits.map((b, i) => (
                <div key={i} style={{
                  padding: '7px 10px', marginBottom: 5,
                  background: 'rgba(255,255,255,0.03)',
                  border: '1px solid rgba(255,255,255,0.06)',
                  borderRadius: 8, fontSize: 12, color: '#94a3b8',
                }}>✓ {b}</div>
              ))}
            </div>
          )}

          {/* Próxima nómina */}
          {employee?.payroll?.nextPayment && (
            <div style={{
              background: 'rgba(16,185,129,0.07)', border: '1px solid rgba(16,185,129,0.2)',
              borderRadius: 12, padding: '12px 14px', marginBottom: 18,
            }}>
              <div style={{ fontSize: 11, color: '#10b981', fontWeight: 600, marginBottom: 4 }}>💰 PRÓXIMO PAGO</div>
              <div style={{ fontSize: 14, color: '#e8ecf4', fontWeight: 600 }}>{employee.payroll.nextPayment}</div>
            </div>
          )}

          {/* Logout */}
          <div style={{ marginTop: 'auto', paddingTop: 16, borderTop: '1px solid var(--border)' }}>
            <button onClick={onLogout} style={{
              width: '100%', padding: '10px',
              background: 'rgba(220,60,60,0.08)', border: '1px solid rgba(220,60,60,0.22)',
              borderRadius: 10, color: 'var(--red)', fontSize: 13, cursor: 'pointer',
              fontFamily: "'DM Sans', sans-serif",
            }}>
              Cerrar sesión
            </button>
          </div>
        </div>
      </div>

      {/* ── CHAT MAIN ── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>

        {/* Topbar */}
        <div style={{
          padding: '13px 20px', borderBottom: '1px solid var(--border)',
          background: 'rgba(9,18,34,0.88)', backdropFilter: 'blur(12px)',
          display: 'flex', alignItems: 'center', gap: 14, flexShrink: 0,
        }}>
          <button onClick={() => setSidebar(s => !s)} style={{
            background: 'none', border: 'none', color: 'var(--muted)',
            cursor: 'pointer', fontSize: 20, lineHeight: 1, padding: 4,
          }}>☰</button>

          <div style={{
            width: 36, height: 36, borderRadius: '50%',
            background: 'linear-gradient(135deg, #c9a84c, #8a6820)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, color: '#fff', boxShadow: '0 3px 10px rgba(201,168,76,0.35)',
          }}>✦</div>

          <div>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 15, color: '#f0f4ff' }}>
              Aria · RRHH Grupo Popper
            </div>
            <div style={{ fontSize: 11, color: '#10b981', display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981', display: 'inline-block' }} />
              En línea · Datos sincronizados con Naaloo
            </div>
          </div>

          <div style={{
            marginLeft: 'auto', fontSize: 12, color: 'var(--muted)',
            padding: '5px 12px', background: 'rgba(255,255,255,0.04)',
            border: '1px solid var(--border)', borderRadius: 20,
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            👤 {firstName} · {employee?.area}
          </div>
        </div>

        {/* Messages */}
        <div style={{
          flex: 1, overflowY: 'auto', padding: '26px 22px 14px',
          scrollbarWidth: 'thin', scrollbarColor: '#1e3a5f transparent',
        }}>
          {messages.map((msg, i) => <Bubble key={i} msg={msg} />)}
          <div ref={bottomRef} />
        </div>

        {/* Quick questions */}
        {isFirst && (
          <div style={{ padding: '0 20px 12px', display: 'flex', flexWrap: 'wrap', gap: 7 }}>
            {QUICK_Q.map((q, i) => (
              <button key={i} onClick={() => send(q.label)} disabled={loading}
                style={{
                  background: 'rgba(201,168,76,0.06)', border: '1px solid rgba(201,168,76,0.18)',
                  borderRadius: 20, padding: '7px 14px', color: 'var(--muted)',
                  fontSize: 12, cursor: 'pointer', fontFamily: "'DM Sans', sans-serif",
                  display: 'flex', alignItems: 'center', gap: 6, transition: 'all 0.2s',
                }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(201,168,76,0.13)'; e.currentTarget.style.color = 'var(--gold2)' }}
                onMouseLeave={e => { e.currentTarget.style.background = 'rgba(201,168,76,0.06)'; e.currentTarget.style.color = 'var(--muted)' }}
              >
                {q.icon} {q.label}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div style={{
          padding: '12px 20px 20px', borderTop: '1px solid var(--border)',
          background: 'rgba(9,18,34,0.75)',
          display: 'flex', gap: 10, alignItems: 'flex-end', flexShrink: 0,
        }}>
          <textarea
            ref={inputRef} value={input} rows={1} disabled={loading}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input) } }}
            onInput={e => { e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px' }}
            onFocus={e => e.target.style.borderColor = 'rgba(201,168,76,0.5)'}
            onBlur={e => e.target.style.borderColor = 'rgba(201,168,76,0.18)'}
            placeholder="Escribí tu consulta de RRHH... (Enter para enviar)"
            style={{
              flex: 1, resize: 'none', overflowY: 'auto',
              background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(201,168,76,0.18)',
              borderRadius: 14, padding: '13px 16px', color: 'var(--text)',
              fontSize: 14, fontFamily: "'DM Sans', sans-serif",
              outline: 'none', lineHeight: 1.5, maxHeight: 120, transition: 'border-color 0.2s',
            }}
          />
          <button
            onClick={() => send(input)} disabled={loading || !input.trim()}
            style={{
              width: 46, height: 46, borderRadius: '50%', flexShrink: 0,
              background: input.trim() && !loading ? 'linear-gradient(135deg, #c9a84c, #9a7230)' : 'rgba(255,255,255,0.06)',
              border: 'none', cursor: input.trim() && !loading ? 'pointer' : 'default',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18, transition: 'all 0.2s',
              boxShadow: input.trim() && !loading ? '0 4px 16px rgba(201,168,76,0.32)' : 'none',
            }}
          >
            {loading ? <Spinner size={18} /> : '➤'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── APP ROOT ────────────────────────────────────────────────
export default function App() {
  const [session, setSession]   = useState(null)
  const [employee, setEmployee] = useState(null)
  const [loadingEmp, setLoadingEmp] = useState(false)

  // Restaurar sesión al recargar
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) handleSession(session)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) { setSession(null); setEmployee(null) }
    })
    return () => subscription.unsubscribe()
  }, [])

  const handleSession = async (sess) => {
    setSession(sess)
    setLoadingEmp(true)
    try {
      const res = await fetch('/api/employee', {
        headers: { 'Authorization': `Bearer ${sess.access_token}` },
      })
      if (res.ok) {
        const emp = await res.json()
        setEmployee(emp)
      }
    } catch (e) { console.error(e) }
    finally { setLoadingEmp(false) }
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setSession(null); setEmployee(null)
  }

  if (!session) return <><style>{G}</style><LoginScreen onLogin={handleSession} /></>

  if (loadingEmp) return (
    <>
      <style>{G}</style>
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
        <Logo size={60} />
        <Spinner size={28} />
        <p style={{ color: 'var(--gold)', fontFamily: "'Outfit', sans-serif", fontSize: 15 }}>
          Cargando tu perfil desde Naaloo...
        </p>
      </div>
    </>
  )

  return (
    <>
      <style>{G}</style>
      <ChatScreen session={session} employee={employee} onLogout={handleLogout} />
    </>
  )
}
