-- ================================================================
--  GRUPO POPPER · HR Chatbot — Schema Supabase
--  Ejecutar en: supabase.com → tu proyecto → SQL Editor → New query
-- ================================================================

-- 1. Tabla de empleados (vincula email corporativo con Naaloo)
CREATE TABLE IF NOT EXISTS public.employees (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email         TEXT UNIQUE NOT NULL,          -- email corporativo
  naaloo_id     TEXT NOT NULL,                 -- ID del empleado en Naaloo
  full_name     TEXT,                          -- nombre (cache para no llamar Naaloo siempre)
  area          TEXT,                          -- área/departamento
  position      TEXT,                          -- cargo
  active        BOOLEAN DEFAULT TRUE,          -- si está activo en la empresa
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Activar Row Level Security (RLS) — cada usuario solo ve su fila
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Empleado ve solo su perfil"
  ON public.employees
  FOR SELECT
  USING (auth.jwt() ->> 'email' = email);

-- 3. Tabla de historial de conversaciones (opcional pero útil)
CREATE TABLE IF NOT EXISTS public.chat_history (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id   UUID REFERENCES public.employees(id) ON DELETE CASCADE,
  role          TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content       TEXT NOT NULL,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.chat_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Empleado ve solo su historial"
  ON public.chat_history
  FOR ALL
  USING (
    employee_id IN (
      SELECT id FROM public.employees WHERE email = auth.jwt() ->> 'email'
    )
  );

-- 4. Índices para performance
CREATE INDEX IF NOT EXISTS idx_employees_email      ON public.employees(email);
CREATE INDEX IF NOT EXISTS idx_chat_history_emp     ON public.chat_history(employee_id);
CREATE INDEX IF NOT EXISTS idx_chat_history_created ON public.chat_history(created_at DESC);

-- ================================================================
--  DATOS DE EJEMPLO — reemplazar con empleados reales
--  IMPORTANTE: primero el empleado debe registrarse via Auth,
--  luego insertar acá con su email.
-- ================================================================
-- INSERT INTO public.employees (email, naaloo_id, full_name, area, position) VALUES
--   ('maria.gonzalez@grupopopper.com', 'NAA-001', 'María González', 'Marketing', 'Coordinadora'),
--   ('juan.perez@grupopopper.com',     'NAA-002', 'Juan Pérez',     'Tecnología', 'Dev Senior');
