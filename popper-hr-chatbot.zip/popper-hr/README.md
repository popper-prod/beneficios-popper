# 🏢 Grupo Popper · HR Chatbot

Asistente virtual de RRHH con IA, autenticación Supabase y datos en tiempo real desde Naaloo.

---

## 🗂️ Estructura del proyecto

```
popper-hr/
├── pages/
│   ├── index.jsx          ← Frontend (login + chat)
│   └── api/
│       ├── chat.js        ← Backend: llama a Mistral (key segura)
│       └── employee.js    ← Backend: llama a Naaloo (key segura)
├── lib/
│   └── supabase.js        ← Cliente de Supabase
├── supabase/
│   └── schema.sql         ← Tablas a crear en Supabase
├── .env.example           ← Variables de entorno necesarias
├── next.config.js
└── package.json
```

---

## 🚀 PASO A PASO: Deploy en Vercel + Supabase

### PASO 1 — Crear proyecto en Supabase (5 min)

1. Ir a **https://supabase.com** → crear cuenta gratuita
2. Click en **"New project"**
   - Nombre: `grupo-popper-hr`
   - Contraseña de DB: guardarla (la vas a necesitar)
   - Región: **South America (São Paulo)**
3. Esperar que el proyecto se cree (~2 min)
4. Ir a **SQL Editor** → **New query**
5. Copiar y pegar todo el contenido de `supabase/schema.sql` → **Run**
6. Ir a **Settings → API** y copiar:
   - `Project URL` → es tu `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public key` → es tu `NEXT_PUBLIC_SUPABASE_ANON_KEY`

---

### PASO 2 — Crear usuarios en Supabase Auth

1. En Supabase ir a **Authentication → Users → Add user**
2. Agregar cada empleado con su email corporativo y contraseña
3. Después de crear el usuario, ir a **SQL Editor** y ejecutar:

```sql
-- Reemplazar con los datos reales del empleado
INSERT INTO public.employees (email, naaloo_id, full_name, area, position)
VALUES ('maria.gonzalez@grupopopper.com', 'ID-EN-NAALOO', 'María González', 'Marketing', 'Coordinadora');
```

> ⚠️ El `naaloo_id` es el ID que le asigna Naaloo a cada empleado.
> Lo encontrás en Naaloo → perfil del empleado → URL o campo ID.

---

### PASO 3 — Subir el código a GitHub (3 min)

1. Crear cuenta en **https://github.com** si no tenés
2. Click en **"New repository"** → nombre: `grupo-popper-hr` → **Create**
3. En tu computadora, abrir una terminal en la carpeta del proyecto:

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/TU-USUARIO/grupo-popper-hr.git
git push -u origin main
```

> 💡 Si no tenés git instalado: https://git-scm.com/downloads

---

### PASO 4 — Deploy en Vercel (3 min)

1. Ir a **https://vercel.com** → crear cuenta (podés entrar con GitHub)
2. Click en **"Add New → Project"**
3. Importar el repositorio `grupo-popper-hr`
4. En la sección **"Environment Variables"** agregar:

| Variable | Valor |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | URL de tu proyecto Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Anon key de Supabase |
| `MISTRAL_API_KEY` | Tu API key de Mistral |
| `NAALOO_API_KEY` | Tu API key de Naaloo |
| `NAALOO_BASE_URL` | URL base de Naaloo (consultá con soporte) |

5. Click en **"Deploy"** → en ~2 min está online
6. Vercel te da una URL tipo: `https://grupo-popper-hr.vercel.app`

---

### PASO 5 — Ajustar endpoints de Naaloo

Abrí `pages/api/employee.js` y verificá que los endpoints coincidan
con la documentación real de Naaloo. Los campos están marcados con comentarios `⚠️`.

Pedile a soporte de Naaloo:
- La **URL base** de su API
- Los **endpoints** de empleados, vacaciones, ausencias, nómina, beneficios
- El **formato de autenticación** (API key en header, bearer token, etc.)

---

## 🔒 Seguridad

- Las API keys de Mistral y Naaloo **nunca llegan al browser** — solo las ven las funciones serverless de Vercel
- Supabase maneja la autenticación y el login seguro
- Row Level Security (RLS) activo: cada empleado solo ve sus propios datos

---

## 💰 Costos

| Servicio | Plan gratuito |
|---|---|
| Vercel | ✅ Gratis (hasta 100GB bandwidth/mes) |
| Supabase | ✅ Gratis (hasta 500MB DB, 50k usuarios) |
| Mistral | ✅ Gratis tier disponible |
| Naaloo | Según tu contrato actual |

---

## 📞 Soporte

Para configurar los endpoints de Naaloo, contactar a soporte en:
**https://naaloo.com/soporte**

Para dudas sobre el chatbot: consultar documentación en el repositorio.
